/*
 * This file is part of the BetterBlox distribution.
 * Copyright (c) 2022 cupiditys.
 */

"use strict"

let FetchupdateLog = `## This extension was just released - Expect bugs, features not thoroughly tested.\n\ 6/08/22 - Version 1.0.1\n\n# Added view locked groups\n# Added hide Private Servers\n# Fixed 2 bugs in the unlimited continue section where some game ratings appeared as "NaN" and player counts >999 were not abbriviated.\n\n23/07/22 - Version 1.0.0:\n\n#  Added Appear Offline\n#  Added All time transactions option\n#  Added Vanity Profile URLs\n#  Added Better Develop Page\n#  Added Live game stats\n#  Added Better Continue Section`

if (location.href.includes("BetterBlox")) { //only loads while on settings page to cut down on server usage
    fetch(`https://res.cloudinary.com/cupiditys/raw/upload/v${Math.floor(Math.random() * 999)}/updateLog.txt`)
    .then(response => response.json())
    .then(data => {
        FetchupdateLog = data
    })
}

let categories = [
    {
        name: "Information",
        content: [
            {
                header: `Update Log`,
                preText: FetchupdateLog,
            },
            {
                header: `${chrome.i18n.getMessage("multipleExtensionsName")}`,
                text: `${chrome.i18n.getMessage("multipleExtensionsText")}`
            },
            {
                header: `${chrome.i18n.getMessage("donateName")}`,
                text: `${chrome.i18n.getMessage("donateText")}`
            },
            {
                header: `${chrome.i18n.getMessage("contactName")}`,
                text: `${chrome.i18n.getMessage("contactText")}`
            }
        ]
    },
    {
        name: `${chrome.i18n.getMessage("generalName")}`,
        content: [
            {
                header: `${chrome.i18n.getMessage("utilityName")}`,
                options: [
                    {
                        header: `${chrome.i18n.getMessage("appearOfflineName")}`,
                        text: `${chrome.i18n.getMessage("appearOfflineText")}`,

                        toggleable: true,
                        disabled: false,
                        setting: "general.appearOffline"
                    }
                ]
            },
            {
                header: "",
                options: [
                    {
                        header: `${chrome.i18n.getMessage("allTimeName")}`,
                        text: `${chrome.i18n.getMessage("allTimeText")}`,
    
                        toggleable: true,
                        disabled: false,
                        setting: "general.allTimeTransactions"
                    }
                ]
            },
            {
                header: "",
                options: [
                    {
                        header: `${chrome.i18n.getMessage("vanityName")}`,
                        text: `${chrome.i18n.getMessage("vanityText")}`,

                        toggleable: true,
                        disabled: false,
                        setting: "general.vanityUrls"
                    }
                ]
            },
            {
                header: "",
                options: [
                    {
                        header: `${chrome.i18n.getMessage("continueName")}`,
                        text: `${chrome.i18n.getMessage("continueText")}`,

                        toggleable: true,
                        disabled: false,
                        setting: "general.improvedContinue"
                    }
                ]
            },
            {
                header: "",
                options: [
                    {
                        header: `${chrome.i18n.getMessage("privateServersName")}`,
                        text: `${chrome.i18n.getMessage("privateServersText")}`,

                        toggleable: true,
                        disabled: false,
                        setting: "general.betterVIP"
                    }
                ]
            },
            {
                header: "",
                options: [
                    {
                        header: `${chrome.i18n.getMessage("lockedGroupsName")}`,
                        text: `${chrome.i18n.getMessage("lockedGroupsText")}`,

                        toggleable: true,
                        disabled: false,
                        setting: "general.lockedGroups"
                    }
                ]
            },
            // {
            //     header: "",
            //     options: [
            //         {
            //             header: `${chrome.i18n.getMessage("liveStatsName")}`,
            //             text: `${chrome.i18n.getMessage("liveStatsText")}`,

            //             toggleable: true,
            //             disabled: false,
            //             setting: "general.liveStats"
            //         }
            //     ]
            // },
            {
                header: `${chrome.i18n.getMessage("appearanceText")}`,
                options: [
                    {
                        header: `${chrome.i18n.getMessage("developName")}`,
                        text: `${chrome.i18n.getMessage("developText")}`,

                        toggleable: true,
                        disabled: false,
                        setting: "general.betterLibrary"
                    }
                ]
            }
        ]
    }
]

pages.settings = async () => {
    let a = setInterval(() => {
        if (document.querySelector("#container-main > div.content > div") != null) {
            document.querySelector("#container-main > div.content > div").remove()
        }
    }, 0);
    var settingsCooldown = false;
    var selectedCategory = "";

    function getCategory(name) {
        for (let index in categories) {
            let category = categories[index];

            if (String(category.name).toLowerCase() == String(name).toLowerCase()) {
                return category;
            }
        }
        throw new Error(`Could not find category under the name ${name}`);
    }

    function getSetting(setting) {
        let settingCategories = setting.split(".");

        return [settings.getSetting(settingCategories[0], settingCategories[1]), settingCategories];
    }

    function loadCategory(name) {
        if (!settingsCooldown && name != selectedCategory) {
            settingsCooldown = true;

            let category = getCategory(name);

            let previousCategoryElement = $(`.category-${String(selectedCategory).toLowerCase()}`);
            let categoryElement = $(`.category-${String(category.name).toLowerCase()}`);

            previousCategoryElement.removeClass("active");
            categoryElement.addClass("active");

            $(".BetterBlox-settings-content").empty();

            category.content.forEach((categoryContent) => {
                let section = $(`<div class="section"></div>`).appendTo(".BetterBlox-settings-content");

                if (categoryContent.header) {
                    section.append(`<div class="container-header"><h3>${categoryContent.header}</h3></div>`);
                }

                if (categoryContent.preText) {
                    section.append(`</div><div class="section-content"><pre class="text-description">${categoryContent.preText}</pre>`);
                }

                if (categoryContent.text) {
                    section.append(`</div><div class="section-content"><span class="text-description">${categoryContent.text}</span>`);
                }

                if (categoryContent.options) {
                    let sectionContent = $(`</div><div class="section-content"></div>`).appendTo(section);

                    categoryContent.options.forEach((option, index) => {
                        if (option.header && option.text) {
                            sectionContent.append(`<span class="text-lead">${option.header}</span>`);
                            sectionContent.append(`<div class="rbx-divider"></div>`);
                            sectionContent.append(`<span class="text-description">${option.text}</span>`);
                        } else {
                            if (options.length < index) {
                                sectionContent.append(`<div class="rbx-divider"></div>`);
                            }

                            if (option.header) {
                                sectionContent.append(`<span class="text-lead">${option.header}</span>`);
                            }

                            if (option.text) {
                                sectionContent.append(`<span class="text-description">${option.text}</span>`);
                            }
                        }

                        if (option.toggleable) {
                            let getSettingOptions = getSetting(option.setting);
                            let setting = getSettingOptions[0];

                            let toggle = $(`<button id="btn-toggle" class="btn-toggle ${option.disabled ? "disabled" : setting ? "on" : ""}"><span class="toggle-flip"></span><span id="toggle-on" class="toggle-on"></span><span id="toggle-off" class="toggle-off"></span></button>`).prependTo(sectionContent);

                            let toggleCoolDown = false;

                            toggle.click(() => {
                                let getSettingOptions = getSetting(option.setting);
                                let setting = getSettingOptions[0];
                                let categories = getSettingOptions[1];

                                if (!toggleCoolDown) {
                                    toggleCoolDown = true;

                                    if (!option.disabled) {
                                        if (setting) {
                                            settings.setSetting(categories[0], categories[1], false);
                                            toggle.removeClass("on");
                                        } else {
                                            settings.setSetting(categories[0], categories[1], true);
                                            toggle.addClass("on");
                                        }
                                    }

                                    toggleCoolDown = false;
                                }
                            })
                        }
                    })
                }

                if (categoryContent.sectionHtml) {
                    section.append(categoryContent.sectionHtml);
                }
            })

            selectedCategory = name;
            settingsCooldown = false;
        }
    }
    async function lol() {
        $.watch("head", () => {
            injectCSS("css/pages/settings.css");
        })

        $.watch(".content", (content) => {
            content.empty();

            $("title")[0].text = "Settings - BetterBlox";

            content.append(`
            <div id="BetterBlox-settings">
                <h1>BetterBlox Beta Settings</h1>
                
                <div class="menu-vertical-container">
                    <ul id="vertical-menu" class="menu-vertical submenus">

                    </ul>
                </div>

            <div class="BetterBlox-settings-content">

            </div>

            </div>`);
            clearInterval(a)
            categories.forEach((category) => {
                $("#vertical-menu.menu-vertical.submenus").append(`
                <li class="menu-option category-${String(category.name).toLowerCase()}">
                    <a class="menu-option-content">
                        <span class="menu-text">${category.name}</span>
                    </a>
                </li>`);
                
                $(`.category-${String(category.name).toLowerCase()}`).click(()=> {
                    loadCategory(category.name);
                });
            })
            loadCategory("Information");
        })
    }
    await lol()
}