/*
 * This file is part of the BetterBlox distribution.
 * Copyright (c) 2022 cupiditys.
 */

//todo: drag and drop & unlimited outfits

"use strict"

pages.avatar = () => {
}