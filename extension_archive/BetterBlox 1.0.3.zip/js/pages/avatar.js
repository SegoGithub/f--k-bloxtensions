/*
 * This file is part of the BetterBlox distribution.
 * Copyright (c) 2023 cupiditys.
 */

//todo: drag and drop & unlimited outfits

"use strict"

pages.avatar = () => {
}