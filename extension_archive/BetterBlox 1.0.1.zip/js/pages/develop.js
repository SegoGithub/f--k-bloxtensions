/*
 * This file is part of the BetterBlox distribution.
 * Copyright (c) 2022 cupiditys.
 */

"use strict"

pages.develop = async () => {
    let request = await BetterBlox.get("https://accountsettings.roblox.com/v1/themes/user")
    if (request.themeType != undefined) {
        if (!settings.getSetting("general", "betterLibrary")) {
            document.querySelector(`link[href*="${chrome.runtime.getURL("/css/pages/develop.css")}"]`).remove()
        } else {
            //really gotta make sure huh
            $("#rbx-body").attr('class', `rbx-body ${request.themeType.toLowerCase()}-theme gotham-font`)
            window.addEventListener('load', function () {
                $("#rbx-body").attr('class', `rbx-body ${request.themeType.toLowerCase()}-theme gotham-font`)
            })
            let a = setInterval(() => {
                $("#rbx-body").attr('class', `rbx-body ${request.themeType.toLowerCase()}-theme gotham-font`)
            }, 0);
            setTimeout(() => {
                clearInterval(a)
            }, 2000);
        }
    } else {
        console.log("bruh")
    }
}