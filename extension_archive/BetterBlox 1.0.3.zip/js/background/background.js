chrome.action.onClicked.addListener(() => {
    chrome.tabs.update({url: "https://roblox.com/BetterBlox/settings"});
})
chrome.runtime.setUninstallURL('https://forms.gle/RRqu2qXsY7DqhZqB7');