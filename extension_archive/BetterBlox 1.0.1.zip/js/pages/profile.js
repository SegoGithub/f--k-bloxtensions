/*
 * This file is part of the BetterBlox distribution.
 * Copyright (c) 2022 cupiditys.
 */

"use strict"

pages.profile = async (userId) => {
}