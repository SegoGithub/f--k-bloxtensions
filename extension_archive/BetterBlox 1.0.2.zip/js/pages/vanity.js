/*
 * This file is part of the BetterBlox distribution.
 * Copyright (c) 2022 cupiditys.
 */

"use strict"

//idea:group wall anti-spam

pages.vanity = async () => {
    if (settings.getSetting("general", "vanityUrls")) {
        let user = location.pathname.split("/")[2]
        let a = setInterval(() => {
            if (document.querySelector("#container-main > div.content > div") != null) {
                document.querySelector("#container-main > div.content > div").remove()
            }
        }, 0);
        let request = await BetterBlox.get(`https://api.roblox.com/users/get-by-username?username=${user}`)
        if (request.Id != undefined) {
            clearInterval(a)
            location.href = `https://www.roblox.com/users/${request.Id}/profile`
        } else {
            clearInterval(a)
            location.href = "https://www.roblox.com/request-error?code=404"
        }
    } else {
        location.href = "https://www.roblox.com/request-error?code=404"
    }
}