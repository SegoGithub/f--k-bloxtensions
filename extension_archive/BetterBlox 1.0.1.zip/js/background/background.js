chrome.action.onClicked.addListener(() => {
    chrome.tabs.update({url: "https://roblox.com/BetterBlox/settings"});
})